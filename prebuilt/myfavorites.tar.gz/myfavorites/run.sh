#!/bin/bash
dir=$(dirname $(readlink -f "$0"))
cd "$dir/jre-13/bin"

args=
for arg in "$@"
do
    args="$args $arg"
done

java $args -jar $dir/myfavorites.jar &
